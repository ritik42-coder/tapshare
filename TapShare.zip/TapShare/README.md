# TapShare 📲✨

Offline file sharing for Android. Pick files on one phone, **touch the tops of two
phones together**, tap the other device — and the files fly across. No internet,
no accounts, no cloud. 100% peer-to-peer over **Wi-Fi Direct**.

Inspired by Apple's AirDrop-style experience.

## Features

- ✅ **100% offline** — Wi-Fi Direct peer-to-peer, zero internet needed
- ✅ **Tap to share** — hold *"Touch tops to share"*, tap the other phone in the list, done
- ✅ **Any file type** — photos, videos, PDFs, APKs, zips… (system file picker)
- ✅ **Live progress** — per-file + overall progress and speed-style status
- ✅ **Auto-receive** — receiver just keeps the screen open; files land automatically
- ✅ **Apple-like UI** — clean light/dark, rounded cards, gradient buttons
- ✅ **Proper adaptive app icon** — works on every launcher shape (round/squircle)
- ✅ Receive folder: `Android/data/com.tapshare.app/files/Download/TapShare`
- ✅ Duplicate file names handled automatically (`file(1).pdf`)

## How the "tap to share" works

1. Both phones open TapShare (sender: **Send files**, receiver: **Receive files**).
2. Wi-Fi must be ON; on Android 12 and below **Location** must also be ON
   (required by Android for Wi-Fi Direct).
3. Sender picks files → taps **"Touch tops to share"** → discovery starts.
4. Sender taps the other phone's name in *Nearby phones* — the devices link.
5. Files stream directly phone-to-phone with progress on both screens.

> Honest note: real hardware "top-touch" detection needs NFC/UWB chips, which most
> phones don't expose to apps. This app reproduces the gesture faithfully with a
> tap-and-hold "touch tops" action + instant device discovery — the flow feels the
> same and works on virtually every Android 8.0+ phone, fully offline.

## Build the APK

**Android Studio (recommended):**
1. Clone/unzip this repo → *Open* the folder in Android Studio.
2. Let Gradle sync (it downloads the wrapper automatically — Java 17 required).
3. **Build → Build Bundle(s) / APK(s) → Build APK(s)** → get
   `app/build/outputs/apk/debug/app-debug.apk`.

**Command line:**
```bash
gradle wrapper        # once, if you want ./gradlew
./gradlew assembleDebug
```

**GitHub Actions:** push to GitHub and the included workflow
(`.github/workflows/build.yml`) builds the APK and uploads it as an artifact
on every push — no local setup needed.

## Push to GitHub

```bash
git init
git add .
git commit -m "TapShare: offline tap-to-share file transfer"
git branch -M main
git remote add origin https://github.com/<you>/tapshare.git
git push -u origin main
```

## Permissions (all standard, no tracking)

| Permission | Why |
|---|---|
| `NEARBY_WIFI_DEVICES` | Wi-Fi Direct discovery (Android 13+) |
| `ACCESS_FINE_LOCATION` | Same, on Android 8–12 |
| `INTERNET` | Local socket between the two phones only |

## Tech

- Kotlin, minSdk 26, targetSdk 34
- Wi-Fi Direct (`WifiP2pManager`) for discovery & pairing
- Raw sockets with a tiny handshake protocol (role exchange → file headers → stream)
- No third-party SDKs, no analytics, no servers
