package com.tapshare.app

import android.content.ContentResolver
import android.net.Uri
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.EOFException
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import kotlin.concurrent.thread

data class SharedFile(val uri: Uri, val name: String, val size: Long)

enum class Role { SENDER, RECEIVER }

sealed class TransferEvent {
    data class Progress(
        val fileName: String,
        val bytes: Long,
        val total: Long,
        val fileIndex: Int,
        val fileCount: Int
    ) : TransferEvent()
    data class FileDone(val fileName: String, val path: String) : TransferEvent()
    data class AllDone(val count: Int, val dir: String) : TransferEvent()
    data class Error(val message: String) : TransferEvent()
    object Linked : TransferEvent()
}

object TransferEngine {
    const val PORT = 8888
    private const val CHUNK = 256 * 1024

    fun startServer(
        resolver: ContentResolver,
        files: List<SharedFile>,
        saveDir: File,
        role: Role,
        onEvent: (TransferEvent) -> Unit
    ) {
        thread(name = "tapshare-server") {
            try {
                ServerSocket(PORT).use { server ->
                    server.soTimeout = 180000
                    val socket = server.accept()
                    handle(socket, resolver, files, saveDir, role, true, onEvent)
                }
            } catch (e: Exception) {
                onEvent(TransferEvent.Error(e.message ?: "Server error"))
            }
        }
    }

    fun startClient(
        owner: InetAddress,
        resolver: ContentResolver,
        files: List<SharedFile>,
        saveDir: File,
        role: Role,
        onEvent: (TransferEvent) -> Unit
    ) {
        thread(name = "tapshare-client") {
            var last: Exception? = null
            for (attempt in 1..25) {
                try {
                    Socket().use { socket ->
                        socket.connect(InetSocketAddress(owner, PORT), 4000)
                        handle(socket, resolver, files, saveDir, role, false, onEvent)
                    }
                    return@thread
                } catch (e: Exception) {
                    last = e
                    Thread.sleep(600)
                }
            }
            onEvent(TransferEvent.Error("Peer not reachable: ${last?.message}"))
        }
    }

    private fun handle(
        socket: Socket,
        resolver: ContentResolver,
        files: List<SharedFile>,
        saveDir: File,
        role: Role,
        isServer: Boolean,
        onEvent: (TransferEvent) -> Unit
    ) {
        socket.soTimeout = 120000
        saveDir.mkdirs()
        val input = DataInputStream(BufferedInputStream(socket.getInputStream()))
        val output = DataOutputStream(BufferedOutputStream(socket.getOutputStream()))
        onEvent(TransferEvent.Linked)

        val peerRole: Role = if (isServer) {
            Role.valueOf(input.readUTF())
        } else {
            output.writeUTF(role.name)
            output.flush()
            role
        }

        if (peerRole == Role.SENDER) {
            receive(input, saveDir, onEvent)
        } else {
            send(output, resolver, files, onEvent)
        }
    }

    private fun send(
        out: DataOutputStream,
        resolver: ContentResolver,
        files: List<SharedFile>,
        onEvent: (TransferEvent) -> Unit
    ) {
        out.writeInt(files.size)
        files.forEachIndexed { index, f ->
            out.writeUTF(f.name)
            out.writeLong(f.size)
            var sent = 0L
            val stream = resolver.openInputStream(f.uri)
                ?: throw IOException("Cannot open ${f.name}")
            stream.buffered().use { ins ->
                val buf = ByteArray(CHUNK)
                while (true) {
                    val r = ins.read(buf)
                    if (r < 0) break
                    out.write(buf, 0, r)
                    sent += r
                    onEvent(TransferEvent.Progress(f.name, sent, f.size, index + 1, files.size))
                }
            }
            out.flush()
            onEvent(TransferEvent.FileDone(f.name, f.name))
        }
        out.flush()
        onEvent(TransferEvent.AllDone(files.size, ""))
    }

    private fun receive(
        input: DataInputStream,
        saveDir: File,
        onEvent: (TransferEvent) -> Unit
    ) {
        val count = input.readInt()
        for (i in 1..count) {
            val name = input.readUTF()
            val size = input.readLong()
            val dest = uniqueFile(saveDir, name)
            var got = 0L
            FileOutputStream(dest).buffered().use { fos ->
                val buf = ByteArray(CHUNK)
                while (got < size) {
                    val want = minOf(buf.size.toLong(), size - got).toInt()
                    val r = input.read(buf, 0, want)
                    if (r < 0) throw EOFException("Connection closed early")
                    fos.write(buf, 0, r)
                    got += r
                    onEvent(TransferEvent.Progress(name, got, size, i, count))
                }
            }
            onEvent(TransferEvent.FileDone(name, dest.absolutePath))
        }
        onEvent(TransferEvent.AllDone(count, saveDir.absolutePath))
    }

    private fun uniqueFile(dir: File, name: String): File {
        var f = File(dir, name)
        var i = 1
        while (f.exists()) {
            val dot = name.lastIndexOf('.')
            val base = if (dot > 0) name.substring(0, dot) else name
            val ext = if (dot > 0) name.substring(dot) else ""
            f = File(dir, "$base($i)$ext")
            i++
        }
        return f
    }
}
