package com.tapshare.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.WpsInfo
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pInfo
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Looper
import androidx.core.content.ContextCompat
import java.net.InetAddress

class WifiDirectController(
    private val context: Context,
    private val cb: Callback
) {
    interface Callback {
        fun onPeers(peers: List<WifiP2pDevice>)
        fun onConnected(isOwner: Boolean, owner: InetAddress?)
        fun onDisconnected()
        fun onStatus(msg: String)
        fun onError(msg: String)
    }

    private val manager = context.applicationContext
        .getSystemService(Context.WIFI_P2P_SERVICE) as WifiP2pManager
    private var channel: WifiP2pManager.Channel =
        manager.initialize(context, Looper.getMainLooper(), null)
    private var registered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION -> {
                    val st = intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1)
                    if (st != WifiP2pManager.WIFI_P2P_STATE_ENABLED) {
                        cb.onError("Wi-Fi Direct is off. Turn Wi-Fi on.")
                    }
                }
                WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION ->
                    manager.requestPeers(channel, peerListener)
                WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION -> {
                    val info = getP2pInfo(intent)
                    if (info != null && info.groupFormed) {
                        cb.onConnected(info.isGroupOwner, info.groupOwnerAddress)
                    } else {
                        cb.onDisconnected()
                    }
                }
            }
        }
    }

    private val peerListener = WifiP2pManager.PeerListListener { list ->
        cb.onPeers(list.deviceList.toList())
    }

    @Suppress("DEPRECATION")
    private fun getP2pInfo(intent: Intent): WifiP2pInfo? =
        if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(WifiP2pManager.EXTRA_WIFI_P2P_INFO, WifiP2pInfo::class.java)
        } else {
            intent.getParcelableExtra(WifiP2pManager.EXTRA_WIFI_P2P_INFO)
        }

    fun register() {
        val filter = IntentFilter().apply {
            addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION)
        }
        ContextCompat.registerReceiver(context, receiver, filter, ContextCompat.RECEIVER_EXPORTED)
        registered = true
    }

    fun unregister() {
        if (registered) {
            runCatching { context.unregisterReceiver(receiver) }
            registered = false
        }
    }

    fun refreshChannel() {
        channel = manager.initialize(context, Looper.getMainLooper(), null)
    }

    fun discover() {
        manager.discoverPeers(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() = cb.onStatus("Looking for nearby phones…")
            override fun onFailure(reason: Int) =
                cb.onError("Discovery failed: ${reasonText(reason)}. Is Wi-Fi on? Location on?")
        })
    }

    fun stop() {
        manager.stopPeerDiscovery(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {}
            override fun onFailure(reason: Int) {}
        })
        manager.cancelConnect(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {}
            override fun onFailure(reason: Int) {}
        })
    }

    fun connect(device: WifiP2pDevice) {
        val config = WifiP2pConfig().apply {
            deviceAddress = device.deviceAddress
            wps.setup = WpsInfo.PBC
        }
        manager.connect(channel, config, object : WifiP2pManager.ActionListener {
            override fun onSuccess() = cb.onStatus("Linking with ${device.deviceName}…")
            override fun onFailure(reason: Int) =
                cb.onError("Connect failed: ${reasonText(reason)}")
        })
    }

    private fun reasonText(r: Int) = when (r) {
        WifiP2pManager.P2P_UNSUPPORTED -> "P2P unsupported on this device"
        WifiP2pManager.BUSY -> "Wi-Fi is busy, retry in a moment"
        else -> "error code $r"
    }
}
