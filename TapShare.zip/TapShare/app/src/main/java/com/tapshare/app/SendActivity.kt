package com.tapshare.app

import android.content.Intent
import android.net.Uri
import android.net.wifi.p2p.WifiP2pDevice
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.net.InetAddress

class SendActivity : AppCompatActivity() {

    private val picked = mutableListOf<SharedFile>()
    private lateinit var controller: WifiDirectController
    private lateinit var filesAdapter: ArrayAdapter<String>
    private lateinit var peersAdapter: ArrayAdapter<String>
    private var peers: List<WifiP2pDevice> = emptyList()
    private var linked = false
    private var doneBytesBase = 0L

    private val pickLauncher =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            uris.forEach { uri ->
                runCatching {
                    contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                }
                picked.add(queryMeta(uri))
            }
            refreshFiles()
        }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted ->
            if (granted.values.isNotEmpty() && granted.values.all { it }) beginDiscovery()
            else toast("Permission is needed to find nearby phones")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_send)

        filesAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf())
        findViewById<ListView>(R.id.fileList).adapter = filesAdapter
        peersAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf())
        findViewById<ListView>(R.id.peerList).adapter = peersAdapter
        findViewById<ListView>(R.id.peerList).setOnItemClickListener { _, _, pos, _ ->
            if (!linked) peers.getOrNull(pos)?.let { controller.connect(it) }
        }

        findViewById<View>(R.id.btnPick).setOnClickListener {
            pickLauncher.launch(arrayOf("*/*"))
        }
        findViewById<View>(R.id.btnShare).setOnClickListener {
            when {
                picked.isEmpty() -> toast("Pick files first")
                !PermHelper.hasAll(this) -> permLauncher.launch(PermHelper.requiredPerms())
                !PermHelper.isLocationOn(this) ->
                    toast("Turn on Location (Wi-Fi Direct needs it on this Android version)")
                else -> beginDiscovery()
            }
        }

        controller = WifiDirectController(this, callback)
        if (picked.isEmpty()) pickLauncher.launch(arrayOf("*/*"))
    }

    private val callback = object : WifiDirectController.Callback {
        override fun onPeers(list: List<WifiP2pDevice>) {
            runOnUiThread {
                peers = list
                peersAdapter.clear()
                peersAdapter.addAll(list.map { "${it.deviceName}\n${statusText(it.status)}" })
                peersAdapter.notifyDataSetChanged()
            }
        }

        override fun onConnected(isOwner: Boolean, owner: InetAddress?) {
            runOnUiThread { status("Linked! Sending…") }
            if (linked) return
            if (owner == null) {
                runOnUiThread { status("Connected, but no owner address. Retry.") }
                return
            }
            linked = true
            controller.stop()
            TransferEngine.startClient(
                owner, contentResolver, picked.toList(), saveDir(), Role.SENDER
            ) { ev -> runOnUiThread { onEvent(ev) } }
        }

        override fun onDisconnected() {
            if (!linked) runOnUiThread { status("Not linked yet. Touch tops and pick a phone below.") }
        }

        override fun onStatus(msg: String) = runOnUiThread { status(msg) }
        override fun onError(msg: String) = runOnUiThread {
            status(msg)
            toast(msg)
        }
    }

    private fun onEvent(ev: TransferEvent) {
        when (ev) {
            is TransferEvent.Linked -> {
                status("Linked! Sending…")
                findViewById<ProgressBar>(R.id.progress).visibility = View.VISIBLE
                findViewById<TextView>(R.id.bigPct).visibility = View.VISIBLE
            }
            is TransferEvent.Progress -> {
                val total = picked.sumOf { it.size }.coerceAtLeast(1L)
                if (ev.bytes == 0L) doneBytesBase =
                    picked.take(ev.fileIndex - 1).sumOf { it.size }
                val overall = ((doneBytesBase + ev.bytes) * 1000 / total).toInt()
                findViewById<ProgressBar>(R.id.progress).progress = overall
                val pct = if (ev.total > 0) (ev.bytes * 100 / ev.total).toInt() else 0
                bigPct("File ${ev.fileIndex}/${ev.fileCount}: ${ev.fileName} — $pct%")
                status("${mb(doneBytesBase + ev.bytes)} / ${mb(total)} MB")
            }
            is TransferEvent.FileDone -> status("Sent ${ev.fileName}")
            is TransferEvent.AllDone -> {
                bigPct("✓ Sent ${ev.count} file(s)")
                status("Done. Files delivered to the other phone.")
            }
            is TransferEvent.Error -> {
                status("Error: ${ev.message}")
                toast(ev.message)
            }
        }
    }

    private fun beginDiscovery() {
        controller.refreshChannel()
        findViewById<View>(R.id.peersLabel).visibility = View.VISIBLE
        status("Bring the tops of both phones together, then tap the other phone below.")
        controller.discover()
    }

    private fun queryMeta(uri: Uri): SharedFile {
        var name = uri.lastPathSegment ?: "file"
        var size = 0L
        runCatching {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val si = c.getColumnIndex(OpenableColumns.SIZE)
                if (c.moveToFirst()) {
                    if (ni >= 0) c.getString(ni)?.let { name = it }
                    if (si >= 0) size = c.getLong(si)
                }
            }
        }
        return SharedFile(uri, name, size)
    }

    private fun refreshFiles() {
        filesAdapter.clear()
        filesAdapter.addAll(picked.map { "${it.name}  ·  ${mb(it.size)} MB" })
        filesAdapter.notifyDataSetChanged()
    }

    private fun status(msg: String) = findViewById<TextView>(R.id.status).setText(msg)
    private fun bigPct(msg: String) = findViewById<TextView>(R.id.bigPct).setText(msg)
    private fun mb(bytes: Long) = "%.1f".format(bytes / 1048576.0)
    private fun saveDir() = File(getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS), "TapShare")
    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun statusText(s: Int) = when (s) {
        WifiP2pDevice.AVAILABLE -> "Tap to send"
        WifiP2pDevice.INVITED -> "Linking…"
        WifiP2pDevice.CONNECTED -> "Connected"
        else -> "Available"
    }

    override fun onResume() {
        super.onResume()
        controller.register()
        controller.refreshChannel()
    }

    override fun onPause() {
        controller.unregister()
        controller.stop()
        super.onPause()
    }
}
