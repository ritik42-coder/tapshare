package com.tapshare.app

import android.os.Bundle
import android.view.View
import android.view.animation.Animation
import android.view.animation.TranslateAnimation
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.net.InetAddress

class ReceiveActivity : AppCompatActivity() {

    private lateinit var controller: WifiDirectController
    private lateinit var receivedAdapter: ArrayAdapter<String>
    private var linked = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_receive)

        receivedAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf())
        findViewById<ListView>(R.id.receivedList).adapter = receivedAdapter
        findViewById<TextView>(R.id.path).text =
            "Files will be saved to: ${saveDir().absolutePath}"

        startPhoneAnimation()
        controller = WifiDirectController(this, callback)
    }

    private val callback = object : WifiDirectController.Callback {
        override fun onPeers(peers: List<android.net.wifi.p2p.WifiP2pDevice>) {}

        override fun onConnected(isOwner: Boolean, owner: InetAddress?) {
            if (linked) return
            linked = true
            runOnUiThread { status("Linked! Waiting for files…", "Receiving…") }
            val resolver = contentResolver
            val dir = saveDir()
            if (isOwner) {
                TransferEngine.startServer(resolver, emptyList(), dir, Role.RECEIVER) { ev ->
                    runOnUiThread { onEvent(ev) }
                }
            } else if (owner != null) {
                TransferEngine.startClient(owner, resolver, emptyList(), dir, Role.RECEIVER) { ev ->
                    runOnUiThread { onEvent(ev) }
                }
            }
        }

        override fun onDisconnected() {
            if (!linked) runOnUiThread {
                status("Keep this screen open.", "Waiting for the other phone to touch tops…")
            }
        }

        override fun onStatus(msg: String) = runOnUiThread { subStatus(msg) }
        override fun onError(msg: String) = runOnUiThread {
            subStatus(msg)
            Toast.makeText(this@ReceiveActivity, msg, Toast.LENGTH_LONG).show()
        }
    }

    private fun onEvent(ev: TransferEvent) {
        when (ev) {
            is TransferEvent.Linked -> subStatus("Linked! Receiving…")
            is TransferEvent.Progress -> {
                findViewById<ProgressBar>(R.id.progress).visibility = View.VISIBLE
                val pct = if (ev.total > 0) (ev.bytes * 1000 / ev.total).toInt() else 0
                findViewById<ProgressBar>(R.id.progress).progress = pct
                status(
                    "Receiving ${ev.fileName}",
                    "File ${ev.fileIndex} of ${ev.fileCount} — ${pct / 10}%"
                )
            }
            is TransferEvent.FileDone -> {
                receivedAdapter.add("✓ ${ev.fileName}")
                receivedAdapter.notifyDataSetChanged()
            }
            is TransferEvent.AllDone -> {
                status("✓ Received ${ev.count} file(s)", "Saved to ${ev.dir}")
                findViewById<TextView>(R.id.path).text = "Saved to: ${ev.dir}"
            }
            is TransferEvent.Error -> {
                subStatus("Error: ${ev.message}")
                Toast.makeText(this, ev.message, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun startPhoneAnimation() {
        val l = findViewById<View>(R.id.phoneL)
        val r = findViewById<View>(R.id.phoneR)
        val aL = TranslateAnimation(0f, 40f, 0f, 0f).apply {
            duration = 900
            repeatMode = Animation.REVERSE
            repeatCount = Animation.INFINITE
        }
        val aR = TranslateAnimation(0f, -40f, 0f, 0f).apply {
            duration = 900
            repeatMode = Animation.REVERSE
            repeatCount = Animation.INFINITE
        }
        l.startAnimation(aL)
        r.startAnimation(aR)
    }

    private fun status(main: String, sub: String) {
        findViewById<TextView>(R.id.status).text = main
        subStatus(sub)
    }

    private fun subStatus(msg: String) {
        findViewById<TextView>(R.id.subStatus).text = msg
    }

    private fun saveDir() =
        File(getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS), "TapShare")

    override fun onResume() {
        super.onResume()
        controller.register()
        controller.refreshChannel()
    }

    override fun onPause() {
        controller.unregister()
        controller.stop()
        super.onPause()
    }
}
